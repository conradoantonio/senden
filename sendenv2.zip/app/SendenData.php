<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SendenData extends Model
{
    
}
