<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LiberarPedido extends Model
{
    //
}
