@extends('layouts.admin')

@section('main-body')

	<example></example>

@endsection