<template>
    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
            <slot></slot>
        </div>
    </div>
</template>

<script>export default {}</script>
